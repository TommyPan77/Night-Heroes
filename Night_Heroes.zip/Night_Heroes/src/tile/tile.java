/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tile;

import java.awt.image.BufferedImage;

/**
 *
 * @author salas
 */
public class tile {
    public BufferedImage image;
    public boolean collision=false;
}
