/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package tile;

import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.imageio.ImageIO;
import main.GamePanel;

/**
 *
 * @author salas
 */
public class tileManager {
    GamePanel gp;
    public tile[] tile;
    public int mapTileNum[][];
    
    public tileManager(GamePanel gp){
        this.gp = gp;
        tile= new tile[100];
        mapTileNum= new int [gp.maxWorldCol][gp.maxWorldRow];
        getTileImage();
        loadMap("/res/player/Maps/WorldMap01.txt"); 
    }
    public void getTileImage(){
        try {
            tile[0]= new tile();
            tile[0].image=ImageIO.read(getClass().getResourceAsStream("/res/player/Tiles/Pastov3.png"));
            
            tile[1]= new tile();
            tile[1].image=ImageIO.read(getClass().getResourceAsStream("/res/player/Tiles/Arboles arriba izquierda.png"));
            tile[1].collision=true;
            
            tile[2]= new tile();
            tile[2].image=ImageIO.read(getClass().getResourceAsStream("/res/player/Tiles/Arboles arriba derecha.png"));
            tile[2].collision=true;
            
            tile[3]= new tile();
            tile[3].image=ImageIO.read(getClass().getResourceAsStream("/res/player/Tiles/Arboles abajo izquierda(fixed).png"));
            tile[3].collision=true;
            
            tile[4]= new tile();
            tile[4].image=ImageIO.read(getClass().getResourceAsStream("/res/player/Tiles/Arboles abajo derecha(fixed).png"));
            tile[4].collision=true;
            
            tile[5]= new tile();
            tile[5].image=ImageIO.read(getClass().getResourceAsStream("/res/player/Tiles/Arbol pequeño.png")); 
            tile[5].collision=true;
            
            tile[6]= new tile();
            tile[6].image=ImageIO.read(getClass().getResourceAsStream("/res/player/Tiles/Arbol pequeñisimo.png")); 
            
            tile[7]= new tile();
            tile[7].image=ImageIO.read(getClass().getResourceAsStream("/res/player/Tiles/Arbusto.png")); 
            
            tile[8]= new tile();
            tile[8].image=ImageIO.read(getClass().getResourceAsStream("/res/player/Tiles/Arbusto desordenado.png"));
            
            tile[9]= new tile();
            tile[9].image=ImageIO.read(getClass().getResourceAsStream("/res/player/Tiles/Agua arriba izquierda.png"));
            tile[9].collision=true;
            
            tile[10]= new tile();
            tile[10].image=ImageIO.read(getClass().getResourceAsStream("/res/player/Tiles/Agua arriba.png"));
            tile[10].collision=true;
            
            tile[11]= new tile();
            tile[11].image=ImageIO.read(getClass().getResourceAsStream("/res/player/Tiles/Agua arriba derecha.png"));
            tile[11].collision=true;
            
            tile[12]= new tile();
            tile[12].image=ImageIO.read(getClass().getResourceAsStream("/res/player/Tiles/Agua derecha.png"));
            tile[12].collision=true;
            
            tile[13]= new tile();
            tile[13].image=ImageIO.read(getClass().getResourceAsStream("/res/player/Tiles/Agua abajo derecha.png"));
            tile[13].collision=true;
            
            tile[14]= new tile();
            tile[14].image=ImageIO.read(getClass().getResourceAsStream("/res/player/Tiles/Agua abajo.png"));
            tile[14].collision=true;
            
            tile[15]= new tile();
            tile[15].image=ImageIO.read(getClass().getResourceAsStream("/res/player/Tiles/Agua abajo izquierda.png"));
            tile[15].collision=true;
            
            tile[16]= new tile();
            tile[16].image=ImageIO.read(getClass().getResourceAsStream("/res/player/Tiles/Agua izquierda.png"));
            tile[16].collision=true;
            
            tile[17]= new tile();
            tile[17].image=ImageIO.read(getClass().getResourceAsStream("/res/player/Tiles/Agua centro.png"));
            tile[17].collision=true;
            //Agregar demas bloques
            //Crear mapas en un archivo de texto con el indice del bloque, colocar en res.player.Maps
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    public void loadMap(String filePath){
        try{
            InputStream is = getClass().getResourceAsStream(filePath);
            BufferedReader br=new BufferedReader(new InputStreamReader(is));
            int col=0;
            int row=0;
            while(col<gp.maxWorldCol && row< gp.maxWorldRow){
                String line=br.readLine();
                while (col<gp.maxWorldCol){
                    String numbers[]=line.split(" ");
                    int num=Integer.parseInt(numbers[col]);
                    mapTileNum[col][row]=num;
                    col++;
                }
                if (col==gp.maxWorldCol){
                    col=0;
                    row++;
                }
            }
            br.close();
        }catch(Exception e){
            
        }
    
    } 
    public void draw(Graphics2D g2){
        int worldCol=0;
        int worldRow=0;
        //Tamaño de la ventana 20x12 pixels
        while (worldCol<gp.maxWorldCol && worldRow < gp.maxWorldRow){
            
            int tileNum=mapTileNum[worldCol][worldRow];
            int worldX=worldCol*gp.tileSize;
            int worldY=worldRow*gp.tileSize;
            int screenX =worldX-gp.player.worldX + gp.player.screenX;
            int screenY =worldY-gp.player.worldY + gp.player.screenY;
            if(worldX+gp.tileSize>gp.player.worldX - gp.player.screenX && worldX-gp.tileSize< gp.player.worldX + gp.player.screenX && worldY+gp.tileSize > gp.player.worldY - gp.player.screenY && worldY-gp.tileSize < gp.player.worldY + gp.player.screenY){
                g2.drawImage(tile[tileNum].image,screenX,screenY,gp.tileSize,gp.tileSize,null);
            }
            worldCol++;
            if(worldCol==gp.maxWorldCol){
                worldCol=0;
                worldRow++;
            }
        }
    }
}
