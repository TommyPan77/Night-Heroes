package main;

public class main {
    public static void main(String[] args) {
        new SeleccionPersonaje().setVisible(true);
    }
}

