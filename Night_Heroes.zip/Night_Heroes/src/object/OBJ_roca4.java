package object;

import java.io.IOException;
import javax.imageio.ImageIO;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USER
 */
public class OBJ_roca4 extends SuperObject {
    public OBJ_roca4(){
        name = "roca4";
        try{
            image = ImageIO.read(getClass().getResourceAsStream("/res/player/objects/Roca de armas abajo derecha.png"));
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
